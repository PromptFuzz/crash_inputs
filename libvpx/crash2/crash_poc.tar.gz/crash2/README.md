
# Title: Libvpx encoder crash on accessing unknown address

## What is the expected behavior? What do you see instead?

I am using the libvpx codec to encode frames of video data and writes the encoded data to an output file. However, the codec encoder produced a wild address without raising errors via craft frames. The wild address then caused crash when accessing.

Remote attackers might leverage this vulnerability to cause a denial of service.

## What version are you using? On what operating system?
Version: The master branch.

OS: Ubuntu 20.04
GLIBC version: 2.28

## Can you reproduce using the vpxdec or vpxenc tools? What command line are you using?

This bug is not found on vpxenc. The bug is triggered by a program that using the minor libvpx codec APIs. I have attached the POC program and the POC input in [link].

If you have the same environment as i have used, you can simply reproduce it via:
```
./test.out crash-88e8a1af26fd1efc6806d2b6f58329756f070612
```

The libvpx was built by: 
```
# export the flags.
    SANITIZER_FLAGS="-O2 -fsanitize=address,undefined -fsanitize-address-use-after-scope -g "
    FUZZER_FLAGS="-fsanitize=fuzzer-no-link -fno-omit-frame-pointer -g -DFUZZING_BUILD_MODE_UNSAFE_FOR_PRODUCTION $SANITIZER_FLAGS"
    export CFLAGS="${CFLAGS:-} $FUZZER_FLAGS"
    export CXXFLAGS="${CXXFLAGS:-} $FUZZER_FLAGS"
    export CC=clang
    export CXX=clang
# build the libvpx library.
 LDFLAGS="$CXXFLAGS" LD=$CXX $SRC/libvpx/configure \
        --enable-vp9-highbitdepth \
        --disable-unit-tests \
        --disable-examples \
        --size-limit=12288x12288 \
        --extra-cflags="${extra_c_flags}" \
        --disable-webm-io \
        --enable-debug \
        --enable-shared
    #    --disable-vp8-encoder \
    #    --disable-vp9-encoder
    make -j$(nproc) all
```

The POC program was compiled by:
```
clang++ -fsanitize=fuzzer -O0 -g -fsanitize=address,undefined -ftrivial-auto-var-init=zero -enable-trivial-auto-var-init-zero-knowing-it-will-be-removed-from-clang -I/data/home/loydlv/vbd/llm_fuzz/output/build/libvpx/include -I/data/home/loydlv/vbd/llm_fuzz/src/extern  id_001835.cc -o test.out 
../build/libvpx/lib/libvpx.a
```


## Please provide any additional information below.
When set break point at line 64 in GDB, after the 5-th execution (press 'c' 5 times) you will see that the pkt->data.frame.buf points at an illegal address.

```
     59          // Get encoded data
     60          vpx_codec_iter_t iter = nullptr;
     61          const vpx_codec_cx_pkt_t *pkt = nullptr;
     62          while ((pkt = vpx_codec_get_cx_data(&encoder, &iter)) != nullptr) {
     63              // Write encoded data to output file
●→   64              fwrite(pkt->data.frame.buf, 1, pkt->data.frame.sz, out_file);
     65          }
     66      }
     67      // clean up
     68      fclose(in_file);;
     69      fclose(out_file);;
──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────── threads ────
[#0] Id 1, Name: "test.out", stopped 0x555555b8e726 in LLVMFuzzerTestOneInput (), reason: BREAKPOINT
[#1] Id 2, Name: "test.out", stopped 0x7ffff678d9b8 in nanosleep (), reason: BREAKPOINT
────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────── trace ────
[#0] 0x555555b8e726 → LLVMFuzzerTestOneInput(data=0x634000020800 "", size=0x1c205)
[#1] 0x555555a59e43 → ExecuteCallback()
[#2] 0x555555a454e4 → RunOneTest()
[#3] 0x555555a4aca5 → FuzzerDriver()
[#4] 0x555555a75b63 → main()
─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
gef➤  p pkt->data.frame.buf
Cannot access memory at address 0x8
```