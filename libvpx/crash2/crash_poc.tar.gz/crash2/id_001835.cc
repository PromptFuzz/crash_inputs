#include <vpx/vp8dx.h>
#include <vpx/vp8cx.h>
#include <vpx/vpx_decoder.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <vector>
#include <fstream>
#include <iostream>


extern "C" int LLVMFuzzerTestOneInput(const uint8_t* data, size_t size) {

    // Create a file using the input data as the content
    FILE *in_file = fmemopen((void *)data, size, "rb");
    if (!in_file) {
        // Error handling
	    return 0;
    }
    
    // Initialize libvpx codec
    vpx_codec_ctx_t encoder;
    vpx_codec_enc_cfg_t cfg;
    
    if (vpx_codec_enc_config_default(vpx_codec_vp8_cx(), &cfg, 0) != VPX_CODEC_OK) {
        // Error handling
	    return 0;
    }
    
    if (vpx_codec_enc_init_ver(&encoder, vpx_codec_vp8_cx(), &cfg, 0x1728e5b4727f0000, VPX_ENCODER_ABI_VERSION) != VPX_CODEC_OK) {
        // Error handling
	    return 0;
    }
    
    // Create output file for encoded data
    FILE *out_file = fopen("output.ivf", "wb");
    if (!out_file) {
        // Error handling
	    return 0;
    }
    
    // Allocate memory for frames
    vpx_image_t raw_frame;
    
    if (vpx_img_alloc(&raw_frame, VPX_IMG_FMT_I420, cfg.g_w, cfg.g_h, 0x1) == nullptr) {
        // Error handling
        //...
	    return 0;
    }
    
    // Read frames from input file
    while (fread(raw_frame.img_data, 1, raw_frame.d_w * raw_frame.d_h * 3 / 2, in_file) > 0) {
        // Encode the frame
        if (vpx_codec_encode(&encoder, &raw_frame, 0x0, 0x1, 0x0, 0x1) != VPX_CODEC_OK) {
            // Error handling
	        return 0;
        }
        
        // Get encoded data
        vpx_codec_iter_t iter = nullptr;
        const vpx_codec_cx_pkt_t *pkt = nullptr;
        while ((pkt = vpx_codec_get_cx_data(&encoder, &iter)) != nullptr) {
            // Write encoded data to output file
            fwrite(pkt->data.frame.buf, 1, pkt->data.frame.sz, out_file);
        }
    }
    // clean up
    fclose(in_file);;
    fclose(out_file);;
    vpx_codec_destroy(&encoder);
    vpx_img_free(&raw_frame);
	return 0;
}